%%%-------------------------------------------------------------------
%%% @author bpatton
%%% @copyright (C) 2019, <COMPANY>
%%% @doc
%%%
%%% @end
%%% Created : 30. Nov 2019 5:29 PM
%%%-------------------------------------------------------------------
-module(watcher).
-export([make_watcher/2]).
-author("bpatton").


make_watcher(Sensor_list, 0) ->
  io:fwrite("Initial Sensor List for ~w: ~w~n", [self(), Sensor_list]),
  watcher_process(Sensor_list);

make_watcher(Sensor_list, N) when N>=1->
  {Sid, _} = lists:nth(N, Sensor_list),
  {Pid, _} = spawn_monitor(sensor, sensor_process, [self(), Sid]),
  make_watcher(lists:keyreplace(Sid, 1, Sensor_list, {Pid, Sid}), N-1).

watcher_process(Sensor_list) ->
  receive
    {Sid, Measurement} ->
      io:fwrite("~w : ~w~n",[Sid,Measurement]),
      watcher_process(Sensor_list);
    {'DOWN',_,_,Pid,Reason} ->
      Sid = proplists:get_value(Pid, Sensor_list),
      io:fwrite("~w : ~w~n", [Sid, Reason]),
      {NewPid, _} = spawn_monitor(sensor, sensor_process, [self(), Sid]),
      Newlist = lists:keyreplace(Pid, 1, Sensor_list, {NewPid, Sid}),
      io:fwrite("Updated Sensor List for ~w: ~w~n", [self(), Newlist]),
      watcher_process(Newlist)
  end.